package acadglidassignment;

import java.io.IOException;
import java.util.Scanner;

public class Addition {
	public static void main(String[] args) throws IOException {
		try {
			Scanner objScanner = new Scanner(System.in);
			Addition objAddition = new Addition();
			System.out.print("Enter First number\n");
			int inumA = objScanner.nextInt();
			System.out.print("\n Enter Second number\n");
			int inumB = objScanner.nextInt();
			System.out.println("\n Sum of two numbers is" + objAddition.addnum(inumA, inumB));
			objScanner.close();
		} catch (java.util.InputMismatchException ex) {
			System.out.println("Please enter a valid input");
		}
	}

	public int addnum(int a, int b) {
		if (b == 0)
			return a;
		int sum = a ^ b; // SUM of two integer is A XOR B
		int carry = (a & b) << 1; // CARRY of two integer is A AND B
		return addnum(sum, carry);

	}
}
